package com.dicoding.picodiploma.loginwithanimation.view.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.loginwithanimation.data.pref.ListStoryItem
import com.dicoding.picodiploma.loginwithanimation.databinding.StoryItemBinding

class AdapterStory (private val listStories: ArrayList<ListStoryItem>) : RecyclerView.Adapter<AdapterStory.ViewHolder>() {


        private lateinit var onItemClickCallback: OnItemClickCallback

        fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
            this.onItemClickCallback = onItemClickCallback
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding =
                StoryItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun getItemCount(): Int = listStories.size

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(listStories[position], onItemClickCallback)
        }

        class ViewHolder(private val binding: StoryItemBinding) :
            RecyclerView.ViewHolder(binding.root) {
            fun bind(story: ListStoryItem, clickCallback: OnItemClickCallback) {
                with(binding) {
                    Glide.with(itemView.context)
                        .load(story.photoUrl)
                        .into(imageView)

                    Judul.text = story.name

                    itemView.setOnClickListener {
                        val sharedViews = arrayOf(
                            Pair(imageView ,"profile"),
                            Pair(Judul ,"name")
                        )
                        clickCallback.onItemClicked(story, sharedViews)
                    }
            }
        }
    }
    interface OnItemClickCallback {
        fun onItemClicked(data: ListStoryItem, sharedViews: Array<Pair<View, String>>)
    }
}